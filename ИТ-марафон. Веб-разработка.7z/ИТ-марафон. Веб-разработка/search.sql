-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Июл 26 2023 г., 09:14
-- Версия сервера: 10.3.13-MariaDB
-- Версия PHP: 7.1.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `search`
--

-- --------------------------------------------------------

--
-- Структура таблицы `table_name`
--

CREATE TABLE `table_name` (
  `page_id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `descr` text NOT NULL,
  `title_link` text NOT NULL,
  `category` varchar(50) NOT NULL,
  `uniq_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `table_name`
--

INSERT INTO `table_name` (`page_id`, `title`, `descr`, `title_link`, `category`, `uniq_id`) VALUES
(1, 'УАвиаК-МЦК расписание', 'График, содержащий сведения о времени, месте и последовательности совершения', 'https://uaviak.ru/pages/raspisanie-/#tab3', 'Расписание', 1),
(2, 'УАвиаК-МЦК результаты приёма', 'Начало работы приемной комиссии – 1 июня 2023 года\r\n\r\nВремя работы приемной комиссии :\r\n\r\nС 1.06.23 по 15.08.23- ежедневно с 09-00 до 18 – 00 ,\r\nв субботу с 09-00 до 14-00\r\n\r\nС 16.08.23- кабинет 419 2-ой корпус - ежедневно с 08-00 до 16-00,\r\nв субботу по предварительной записи с 08-00 до 13-00\r\nВыходной – воскресенье.\r\n\r\nПроезд: Маршрутное такси № 82,15,65 до остановки «Учебный центр»\r\nМаршрутные такси до Н. Города до остановки магазин «Чарка», а затем троллейбус № 1, 5, 9, 15, 18 или маршрутное такси № 82,15,65 до остановки «Учебный центр»\r\nТелефон для справок: (8422) 58-41-56\r\n', 'https://uaviak.ru/pages/rezultaty-priema/', 'Приёмная комиссия', 2);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `table_name`
--
ALTER TABLE `table_name`
  ADD PRIMARY KEY (`page_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `table_name`
--
ALTER TABLE `table_name`
  MODIFY `page_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
