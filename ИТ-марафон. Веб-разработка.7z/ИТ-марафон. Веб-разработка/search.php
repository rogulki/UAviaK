<?php 
  if(isset($_POST['submit'])){ 
  if(isset($_GET['go'])){ 
  if(preg_match("^/[A-Za-z]+/", $_POST['name'])){ 
   $name=$_POST['name']; 
  } 
  } 
  else{ 
  echo  "<p>Пожалуйста, введите поисковый запрос</p>"; 
  } 
}?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
<style>
* {
    font-size: 'Manrope';
}
::-webkit-scrollbar {
  width: 20px;
}
::-webkit-scrollbar-track {
  border: 1px solid #fff;
  border-radius: 10px;
  width: 20px;
}
::-webkit-scrollbar-thumb {
  background: #121B3E; 
  border-radius: 10px;
  border: 1px solid #fff;
  width: 20px;
}
::-webkit-scrollbar-thumb:hover {
  background: #ECF1FF; 
  width: 20px;
}
body {
    background: #121B3E;
    color: #191970;
}
.list-group-item-action {
    background: none;
    color: #6176AD;
    transition: all 0.8s ease 0s
}
.list-group-item-action:hover {
    background: none;
    color: #ECF1FF;
    transition: all 0.8s ease 0s;
}
.list-group-item-action:active {
    background: none;
    color: #ECF1FF;
    transition: all 0.8s ease 0s;
}
.list-group-item-action:focus {
    background: none;
    color: #ECF1FF;
    transition: all 0.8s ease 0s;
}
.list-group-item-action:before {
    background: none;
    color: #ECF1FF;
}
.search {
  background-image: url('./images/Search-hover.png');
  align-items: center;
  transition: all 2.8s ease 0s;
  width: 100px;
}
button {
    background: none;    
    border: none;
    cursor: pointer;
    padding: 0;
    margin: 0;
    appearance: none;
    position: relative;
    z-index: 2;
}
form{
    position: relative;
    transition: all 1s;
    width: 50px;
    height: 50px;
    top: -3px;
    background: none;
    box-sizing: border-box;
    border-radius: 25px;
    border: 4px solid none;
    padding: 5px;
}

input{
    position: absolute;
    outline: 0;
    border: 0;
    display: none;
    font-size: 1em;
    padding: 0 20px;
}
.fa{
    box-sizing: border-box;
    padding: 10px;
    width: 42.5px;
    height: 42.5px;
    position: absolute;
    top: -29px;
    border-radius: 50%;
    color: #6197FF;
    background: no-repeat;
    text-align: center;
    font-size: 1.6em;
    transition: all 1s;
}
form:hover,
form:valid{
    width: 200px;
    cursor: pointer;
}

form:hover input,
form:valid input{
    display: block;
}

form:hover .fa,
form:valid .fa{
    color: #121B3E;
    position: absolute;
    left: 120px;
}
a {
    display: none;
    font-size: 20px;
    color: white;
    width: 100%;
}
form:valid a {
    display: block;
}
.fa-glasses {
  align-items: center;
  position: absolute;
  left: -10px;
  transition: all 2.8s ease 0s;
}
.fa-glasses:hover {
  color: #FAFBFF;
  align-items: center;
  position: absolute;
  transition: all 2.8s ease 0s;
}
.smena-snimka-3 {
  background-image: url('./images/Ellipse 740.png');
  align-items: center;
  transition: all 2.8s ease 0s;
}
.smena-snimka-3:hover {
  background-image: url('./images/Ellipse 741.png');
  align-items: center;
  transition: all 2.8s ease 0s;
}
.smena-snimka-2 {
  background-image: url('./images/Ellipse 739.png');
  align-items: center;
  transition: all 2.8s ease 0s;
}
.smena-snimka-2:hover {
  background-image: url('./images/Ellipse 736.png');
  align-items: center;
  transition: all 2.8s ease 0s;
}
.block {
    background: #121B3E;
    font-size: 30px;
    font-weight: 700;
}
.navbar {
    background: #121B3E;
    background-image: url("./images/Ellipse 712.png" style="width: 1000px; position: absolute; top: 200px");
}
.navbar a {
color: #fff;
font-weight: 600;
font-size: 14px;
}
.navbar-toggler img{
color: #fff;
}
.position-absolute {
position: absolute!important;
}
.navbar-expand-lg {
    position: fixed;; 
    top:0;
}
.row {
--bs-gutter-х: 1.5rem;
--bs-gutter-у: 0;
display: flex;
flex-wrap: wrap;
margin-top: calc(-1 * var(--bs-gutter-у));
margin-right: calc(-.5*var(--bs-gutter-x));
margin-left: calc(-.5*var(--bs-gutter-x));
}
.nav-item {
font-size: 16px;
}
.nav-link:hover {
    color: #6176AD;
}
.nav-link:active {
    color: #6176AD;
}
.nav-link:focus {
    color: #6176AD;
}
.offcanvas {
display: none;
background: #121B3E;
color: #fff;

}
 .about {
    position: absolute;
    top: 200px;
    color: #F2F5FF;
    left: 50px;
 }
 .text {
    width: 500px;
 }
 .about-2 {
    position: absolute;
    display: inline-block;
 }
 .about-2 {
    position: absolute;
    top: 400px;
 }
 #list-item-3 {
    background-image: url("./images/Ellipse 713.png" style="width: 1000px; position: absolute; top: -1000px");
 }
 #list-item-1, #list-item-2, #list-item-3, h4 {
    text-align: center;
 }
 .buttons {
    position: fixed;
    top: 300px;
 }
 .default {
    image: url("./pin/defoult.png");
 }
 .default:hover {
    image: url("./pin/active.png");
 }
 @media screen and (max-width: 999px) {
    .navbar-brand img {
        position: absolute;
        left: 35px;
    }
    #list-item-1, #list-item-2, #list-item-3, h4 {
    text-align: left;
 }
 .buttons {
    opacity: 0;
 }
 }
</style>
</head>   
<body>
<header class="position-absolute w-100">
        <nav class="navbar navbar-expand-lg py-5">
            <div class="container">
                <a class="navbar-brand" href="#"><h4 font-weight="700"><img src="./images/logo.png" alt=""></h4></a>
                <div class="d-lg-none d-flex align-items-center gap-4">
                    <a class="nav-link" href="#"><i class="bi bi-search h5"></i></a>
                    <a class="nav-link" href="#"><i class="bi bi-cart3 h5"></i></a>
                    <button class="navbar-toggler border-0 px-4 py-2" type="button" 
                        data-bs-toggle="offcanvas" data-bs-target="#offcanvasTop" aria-controls="offcanvasTop"
                        aria-expanded="false" aria-label="Toggle-navigation" style="position: absolute; left: 450px; top: 68px;">
                        <img src="./ico/Hamburger.png" width="24"> 
                    </button>
                </div>
                <div class="collapse navbar-collapse" id="navbarSupportContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 gap-4">
                        <li></li>
                        <li></li>
                        <li></li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" style="width: 100px">О колледже</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Абитуриентам</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Студентам</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Преподавателям</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Трудоустройство</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Автошкола</a>
                        </li>
                        <li></li>
                        <li></li>
                        <li></li>
                        <li class="nav-item" method="post" action="search.php?go"  id="searchform">
                            <form name="search" method="post" action="search.php">
                                <input type="search" name="query" placeholder="Поиск" style="border-radius: 4px; border: 1px solid #FAFBFF; color: #6197FF; width: 170px; 
                                padding: 5px 45px 5px 10px; box-sizing: border-box; border-shadow: 10px 0 10px 0 #6197FF;" required>
                                <a class="nav-link" href="javascript:void(0)" id="clear-btn" id="clear-btn" type="submit">
                                    <button type="submit">
                                        <i class="search fa fa-search" alt="" type="submit" name="submit" value="Search" size="100"></i>
                                    </button>
                                </a>
                            </form>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" type="submit">
                                <button type="submit">
                                    <i class="vector fa fa-glasses" alt="" type="submit" name="submit" value="vector" size="100"></i>
                                </button>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="offcanvas offcanvas-top" tabindex="-1" id="offcanvasTop" aria-labelledby="offcanvasTopLabel">
                    <div class="offcanvas-header">
                      <h5 class="offcanvas-title" id="offcanvasTopLabel"><img src="./images/logo.png" alt=""></h5>
                      <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                    </div>
                    <div class="offcanvas-body">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0 gap-4 text-center">
                        <li class="nav-item">
                            <a class="nav-link" href="#">О колледже</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Абитуриентам</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Студентам</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Преподавателям</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Трудоустройство</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Автошкола</a>
                        </li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    </header>
<div class="about">
<?php 
$connect = mysqli_connect("localhost", "root", "", "search") or die("Error");
$query = mysqli_query($connect, "SELECT * FROM table_name");
while($row = mysqli_fetch_assoc($query)) echo "<h1>".$row['category']."</h1><p>".$row['title_link']."</p><br><p>".$row['descr']."</p><br>"
?>
</div>
<img src="./images/Ellipse 712.png" style="position: absolute; left:-100px">
<img src="./images/Ellipse 712.png" style="position: absolute; left:-100px">
<script>
        const list = document.getElementById("list");
        const colors = ["#6176AD", "#ECF1FF"]
        list.addEventListener("click", () => {
            console.log("click")
        });
        function  getRandomNumber() {
            return Math.floor(Math.random() * colors.length);
        }
        console.log (getRandomNumer());
       </script> 
       <script>
        $(window).scroll(function(){
if ($(window).scrollTop() > '200'){

    $('#div').css({"background":"url(http://www.fonstola.ru/pic/201111/1600x900/fonstola.ru-55699.jpg);"});
}
if ($(window).scrollTop() > '400'){

    $('#div').css({"background":"url(http://www.zastavki.com/pictures/originals/2012/Backgrounds_Circles_colors_035456_.jpg);"});

}
if ($(window).scrollTop() == $(document).height() - $(window).height()){

    alert($(window).scrollTop());

    $('#div').css({"background":"url(http://www.fonstola.ru/pic/201111/1366x768/fonstola.ru-55713.jpg);"});

}
});
</script>
<script>
var perekhod = document.getElementById('perekhod');
window.addEventListener('scroll', function() {
  if (document.body.scrollTop > 150 || document.documentElement.scrollTop > 150) {
  perekhod.classList.remove('perekhod-1');
  perekhod.classList.add('perekhod-2');
  }  
});
</script>
<script>
    const search = document.querySelector('.search');
    const body = document.querySelector('body');
    search.addEventLinester('click' function(e) {
        event.stopPropagation;
        this.classList.add('.search--active');
    });
    body.addEventLinester('click' function() {
        search.classList.remove('.search--active');
    });
</script>
<script>
    const clearInput = () => {
    const input = document.getElementsByTagName("input")[0];
    input.value = "";
}
const clearBtn = document.getElementById("clear-btn");
clearBtn.addEventListener("click", clearInput);
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" 
    integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" 
    crossorigin="anonymous"></script> 
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>